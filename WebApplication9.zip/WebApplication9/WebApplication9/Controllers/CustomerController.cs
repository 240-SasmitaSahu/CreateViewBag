﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication9.Models;

namespace WebApplication9.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            IList<CustomerProperties> customerpropertiess = new List<CustomerProperties>();
            customerpropertiess.Add(new CustomerProperties() { ID = 123, CustomerName = "SASMITA", CustomerAddress = "BALANGIR" });
            customerpropertiess.Add(new CustomerProperties() { ID = 12, CustomerName = "SMITA", CustomerAddress = "ANGIR" });
            customerpropertiess.Add(new CustomerProperties() { ID = 12, CustomerName = "MITA", CustomerAddress = "NGIR" });

            ViewData["customerpropertiess"] = customerpropertiess;
            ViewBag.TotalCustomer = customerpropertiess.Count();
            ViewBag.CompanyName = "IBL";

            return View();
        }
    }
}
